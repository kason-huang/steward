"""Panda Ego Runtime. Observations enter through the robot port only."""

from __future__ import annotations

import base64
import logging
import threading

from steward.ego.panda_observation import PandaObservationRuntime, policy_inputs
from steward.ego.panda_perception import PandaEvidence
from steward.ego.view import EgoViewRenderer
from steward.glrender import encode_image
from steward.net import HttpError, JsonServer, NO_CONTENT
from steward.scene.schema import Entity, Link, RigidTree, SceneState, exact, pose
from steward.viewloop import ViewLoop, ViewSettings, frame_response

_LOG = logging.getLogger(__name__)


class PandaEgoRuntime:
    def __init__(self, link):
        self.link = link
        self.sensor = PandaObservationRuntime(link)
        self.lock = threading.RLock()
        self.stop_event = threading.Event()
        self.thread = None
        self.latest = None
        self.evidence = PandaEvidence()
        self.scene = SceneState("ego").to_dict()
        renderer = EgoViewRenderer()
        self.view = ViewLoop("panda-ego", lambda settings: self._render(renderer, settings), renderer.close)

    def start(self):
        self.view.start()
        self.thread = threading.Thread(target=self._run, name="panda-observations", daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        if self.thread is not None:
            self.thread.join(timeout=5)
        self.view.stop()

    def _run(self):
        while not self.stop_event.is_set():
            try:
                self.observe()
            except (OSError, HttpError, ValueError, KeyError) as exc:
                _LOG.warning("Panda observation unavailable: %s", exc)
            self.stop_event.wait(0.12)

    def observe(self):
        with self.lock:
            observation = self.sensor.read()
            if observation is None:
                return self.latest
            tool = observation["tool"]
            encoders = observation["encoders"]
            width = abs(encoders["gripper0_finger_joint1"]["position"]
                        - encoders["gripper0_finger_joint2"]["position"])
            robot = Entity("e:panda", "robot", exact("libero-panda"), exact(tool),
                           RigidTree(exact("fixed"), [observed_box("tool", [.06, .08, .035])]),
                           state_vars={"fingerWidth": exact(width)})
            if self.latest is None or self.latest["episodeId"] != observation["episodeId"]:
                self.evidence = PandaEvidence()
            can, basket, grasp, placement, reason = self.evidence.update(observation, width)
            entities = [robot]
            for identifier, category, point, size in (
                ("e:can", "alphabet_soup", can, [.062, .062, .075]),
                ("e:basket", "basket", [*basket[0], basket[1] - .065] if basket is not None else None,
                 [.15, .16, .13]),
            ):
                if point is not None:
                    entities.append(Entity(identifier, "object", exact(category),
                                           exact({"p": list(point), "q": [1, 0, 0, 0]}),
                                           RigidTree(exact("fixed"), [observed_box("observed", size)]),
                                           state_vars={"size": exact(size)}))
            robot.state_vars.update({"grasp": exact(grasp), "placement": exact(placement)})
            scene = SceneState("ego", entities=entities, self_id=robot.id,
                               version=observation["step"], stamp=observation["stamp"])
            self.scene = scene.to_dict()
            self.latest = {"episodeId": observation["episodeId"], "step": observation["step"],
                           "calibrationId": observation["calibrationId"], "scene": self.scene,
                           "judgment": {"grasp": grasp, "placement": placement, "reason": reason,
                                        "target": "e:can" if can is not None else None,
                                        "basket": "e:basket" if basket is not None else None,
                                        "evidenceStep": observation["step"]}}
            self.link.telemetry(self.scene | {"episodeId": observation["episodeId"]})
            return self.latest

    def preview(self):
        with self.lock:
            observation = self.sensor.observation
            if observation is None:
                raise HttpError(409, "Panda has no observation yet")
            try:
                inputs = policy_inputs(observation)
            except ValueError as exc:
                raise HttpError(409, str(exc)) from exc
            return {"episodeId": observation["episodeId"], "step": observation["step"],
                    "observation/state": inputs["observation/state"].tolist(),
                    **{key: base64.b64encode(encode_image(inputs[key])).decode("ascii")
                       for key in ("observation/image", "observation/wrist_image")}}

    def state(self):
        return self.latest

    def _render(self, renderer, settings):
        scene = self.scene
        return renderer.render(scene, settings), "image/jpeg", {"esVersion": scene["version"], "t": scene["stamp"]}


def observed_box(name, size):
    return Link(name, name, {"collision": [
        {"kind": "primitive", "shape": "box", "size": size, "pose": pose()}
    ]})


def panda_ego_api(runtime, port, bind_wait_s):
    def frame(query, body):
        latest = runtime.view.latest(int(query["after"]) if "after" in query else None)
        status = runtime.view.status()
        if latest is not None:
            return frame_response(latest, status)
        if status["settings"] is None:
            raise HttpError(409, "the ego view is not configured")
        if status["error"]:
            raise HttpError(503, status["error"])
        return NO_CONTENT

    return JsonServer({
        ("GET", "/ego/observation"): lambda q, b: runtime.preview(),
        ("GET", "/ego/state"): lambda q, b: runtime.state(),
        ("POST", "/ego/observe"): lambda q, b: runtime.observe(),
        ("GET", "/ego/view"): lambda q, b: runtime.view.status(),
        ("POST", "/ego/view"): lambda q, b: runtime.view.configure(ViewSettings.parse(b)),
        ("GET", "/ego/view/frame"): frame,
    }, port=port, name="panda-ego-api", bind_wait_s=bind_wait_s)
